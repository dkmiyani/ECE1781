#ifndef echo_h__
#define echo_h__
 
extern int printecho(int argc, char **argv);
 
#endif  // echo_h__
