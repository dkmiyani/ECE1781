#ifndef echo_h__
#define echo_h__
 
//extern void echo(int argc, char **argv);
extern int printecho(int argc, char **argv);
 
#endif  // echo_h__
